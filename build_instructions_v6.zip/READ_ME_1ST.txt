DIMENSION DRAWINGS
------------------

No responsibility is taken for the correctness of this information!

You will find additional informations on the XPO CD.
